<?php
session_start();

// Database connection
$host = 'localhost';
$dbname = 'Sales_Blogs';
$username = 'root'; // Your database username
$password = ''; // Your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare statement to check user credentials
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    
    $user = $stmt->fetch();
    
    // Verify user credentials
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        header("Location: index.php");
        exit;
    } else {
        echo "Invalid credentials";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        /* General Styling */
        body {
            font-family: Arial, sans-serif;
            background-image: url('late night.PNG');
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        /* Navigation Styles */
        nav {
            margin-bottom: 20px;
            text-align: center; /* Center the nav text */
        }
        nav ul {
            list-style-type: none;
            padding: 0;
            display: inline-flex; /* Use inline-flex to center the nav */
            justify-content: center; /* Center the links horizontally */
            background-color: #4A90E2;
        }
        nav li {
            margin: 0 20px;
        }
        nav a {
            color: white;
            text-decoration: none;
            padding: 10px;
        }

        /* Login Form Styles */
        .login-form {
            background: rgba(255, 255, 255, 0.6); /* White background with 60% opacity */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.15);
            width: 300px;
            backdrop-filter: blur(5px); /* Adds a blur effect behind the form */
        }
        .login-form input {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .login-form button {
            background-color: #4A90E2;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        .login-form button:hover {
            background-color: #357ABD;
        }
    </style>
</head>
<body>

<nav>
    <ul>
        <li>
            <a href="index.php">Home</a>
        </li>
        <li>
            <a href="register.php">Register</a>
        </li>
        <li>
            <a href="post.php">Posts</a>
        </li>
        <li>
            <a href="logout.php">Logout</a>
        </li>
    </ul>
</nav>

<div class="login-form">
    <h2>Login</h2>
    <form method="POST">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
</div>
</body>
</html>
