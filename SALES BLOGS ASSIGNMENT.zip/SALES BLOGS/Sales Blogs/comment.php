<?php
session_start();

// Database connection
$host = 'localhost';
$dbname = 'Sales_Blogs';
$username = 'root'; // Your database username
$password = ''; // Your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle comment submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $comment = $_POST['comment'];
    if (!empty($_POST['emoji'])) {
        $emoji = $_POST['emoji'];
        $comment .= " " . $emoji; // Append selected emoji to the comment
    }
    $post_id = $_POST['post_id'];

    $stmt = $pdo->prepare("INSERT INTO comments (post_id, user_id, comment) VALUES (?, ?, ?)");
    $stmt->execute([$post_id, $_SESSION['user_id'], $comment]);

    header("Location: index.php"); // Redirect to the index page
    exit;
}

// Fetch the post based on the post ID
if (isset($_GET['id'])) {
    $post_id = $_GET['id'];
    $postStmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
    $postStmt->execute([$post_id]);
    $post = $postStmt->fetch();

    // Fetch comments for the post from the comments table
    $commentStmt = $pdo->prepare("SELECT * FROM comments WHERE post_id = ? ORDER BY created_at DESC");
    $commentStmt->execute([$post_id]);
    $comments = $commentStmt->fetchAll();
} else {
    die("Post not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($post['title']); ?></title>
    <style>
        /* General Styling */
        body {
    font-family: Arial, sans-serif;
    background-image: url('images/background.jpg'); /* Path to your image */
    background-size: cover; /* Scale the image to cover the entire page */
    background-position: center; /* Center the background image */
    background-repeat: no-repeat; /* Prevent the image from repeating */
    color: #333; /* Text color */
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
}

        .container {
            max-width: 800px;
            width: 100%;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .post {
            margin-bottom: 20px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 15px;
        }
        .comment {
            padding: 5px 0;
            border-top: 1px solid #ddd;
            margin-top: 10px;
            color: #555;
        }
        .comment strong {
            color: #333;
        }
        /* Navigation Styling */
        nav {
            width: 100%;
            background-color: #4A90E2;
            padding: 10px 0;
        }
        nav ul {
            list-style-type: none;
            padding: 0;
            display: flex;
            justify-content: center;
        }
        nav li {
            margin-right: 20px;
        }
        nav a {
            color: white;
            text-decoration: none;
            padding: 10px;
        }
    </style>
</head>
<body>
    <!-- Navigation Menu -->
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="post.php">Posts</a></li>
            <li><a href="logout.php">Logout</a></li> 
        </ul>
    </nav>

    <div class="container">
        <div class="post">
            <h1><?php echo htmlspecialchars($post['title']); ?></h1>
            <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
            <?php if ($post['image']): ?>
                <img src="<?php echo htmlspecialchars($post['image']); ?>" alt="Post Image" style="max-width: 100%; border-radius: 5px;">
            <?php endif; ?>
        </div>

        <!-- Comment Form -->
        <?php if (isset($_SESSION['user_id'])): ?>
            <form method="POST">
                <input type="hidden" name="post_id" value="<?php echo $post_id; ?>">
                <textarea name="comment" placeholder="Write a comment..." required></textarea>
                <select name="emoji">
                    <option value="">Select an emoji</option>
                    <option value="😊">😊</option>
                    <option value="😂">😂</option>
                    <option value="❤️">❤️</option>
                    <option value="😢">😢</option>
                    <option value="😡">😡</option>
                </select>
                <button type="submit">Comment</button>
            </form>
        <?php else: ?>
            <p>Please <a href="login.php">login</a> to leave a comment.</p>
        <?php endif; ?>

        <!-- Display Comments -->
        <?php foreach ($comments as $comment): ?>
            <div class="comment">
                <p><strong>User <?php echo htmlspecialchars($comment['user_id']); ?>:</strong> <?php echo nl2br(htmlspecialchars($comment['comment'])); ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
