<?php
session_start();

// Database connection
$host = 'localhost';
$dbname = 'Sales_Blogs';
$username = 'root'; // Your database username
$password = ''; // Your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    exit();
}

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Handle post submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $content = $_POST['content'];
    $image = '';

    // Handle file upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $file = $_FILES['image'];
        $uploadDir = 'images/';
        $uploadFile = $uploadDir . basename($file['name']);

        // Create the directory if it doesn't exist
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        if (move_uploaded_file($file['tmp_name'], $uploadFile)) {
            $image = $uploadFile;
        }
    }

    // Insert post into the database
    $stmt = $pdo->prepare("INSERT INTO posts (user_id, content, image) VALUES (?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $content, $image]);
}

// Fetch posts
$stmt = $pdo->query("SELECT p.*, u.username FROM posts p JOIN users u ON p.user_id = u.id ORDER BY p.created_at DESC");
$posts = $stmt->fetchAll();
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sales Blog</title>
    <style>
        /* General Styles */
        * {
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            background-image: url('late night.PNG');
            color: #333;
            display: flex;
            flex-direction: column; /* Changed to column */
            align-items: center; /* Centering items */
            padding: 20px;
        }
        nav {
            width: 100%; /* Full width */
            background-color: #4A90E2; /* Nav background */
            margin-bottom: 20px; /* Space below nav */
        }
        nav ul {
            list-style-type: none;
            padding: 0;
            display: flex;
            justify-content: center; /* Center nav items */
        }
        nav ul li {
            margin-right: 20px; /* Spacing between items */
        }
        nav ul li a {
            color: white;
            text-decoration: none;
            padding: 10px;
        }

        /* Container Styles */
        .container {
            max-width: 800px;
            width: 100%;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            color: #4A90E2;
            text-align: center;
        }

        /* Form Styles */
        .post-form {
            margin-bottom: 20px;
        }
        .post-form textarea {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ccc;
            resize: none;
            margin-bottom: 10px;
        }
        .post-form input[type="file"] {
            margin-bottom: 10px;
        }
        .post-form button {
            display: inline-block;
            background-color: #4A90E2;
            color: #fff;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .post-form button:hover {
            background-color: #357ABD;
        }

        /* Post Styles */
        .post {
            background: #fafafa;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 15px;
            transition: box-shadow 0.3s ease;
        }
        .post:hover {
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .post h3 {
            margin: 0 0 10px;
            color: #4A90E2;
        }
        .post p {
            line-height: 1.6;
            color: #555;
        }
        .post img {
            max-width: 100%;
            border-radius: 5px;
            margin-top: 10px;
        }
        .post small {
            color: #999;
            font-size: 0.85em;
            display: block;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="login.php">Login</a></li>
            <li><a href="logout.php">Logout</a></li> 
        </ul>
    </nav>
    <div class="container">
        <h2>Welcome to Sales Blog</h2>
        <form class="post-form" method="POST" enctype="multipart/form-data">
            <textarea name="content" required placeholder="What's on your mind?" rows="4"></textarea>
            <input type="file" name="image" accept="image/*"><br>
            <button type="submit">Post</button>
        </form>

        <h1>Blog Posts</h1>
        <?php foreach ($posts as $post): ?>
            <div class="post">
                <h3><?= htmlspecialchars($post['username']); ?></h3>
                <p><?= nl2br(htmlspecialchars($post['content'])); ?></p>
                <?php if ($post['image']): ?>
                    <img src="<?= htmlspecialchars($post['image']); ?>" alt="Post Image">
                <?php endif; ?>
                <small>Posted on <?= htmlspecialchars($post['created_at']); ?></small>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
