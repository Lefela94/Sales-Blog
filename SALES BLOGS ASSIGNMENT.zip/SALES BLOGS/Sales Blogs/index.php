<?php
session_start();
// Database connection
$host = 'localhost';
$dbname = 'Sales_Blogs';
$username = 'root'; // Your database username
$password = ''; // Your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $comment = $_POST['comment'];
    $post_id = $_POST['post_id'];
    $emoji = $_POST['emoji'];

    // Include the selected emoji in the comment
    $full_comment = $emoji ? $comment . " " . $emoji : $comment;

    // Insert comment into the database
    $stmt = $pdo->prepare("INSERT INTO comments (post_id, user_id, comment) VALUES (?, ?, ?)");
    $stmt->execute([$post_id, $_SESSION['user_id'], $full_comment]);

    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sales Blog</title>
    <style>
        /* General Styling */
        body {
            font-family: Arial, sans-serif;
            background-image: url('late night.PNG');
            color: #333;
            display: flex;
            flex-direction: column; /* Changed to column for stacking */
            align-items: center; /* Center items */
            padding: 20px;
        }
        
        /* Navigation Styling */
        nav {
            background-color: #4A90E2;
            width: 100%; /* Ensures it takes full width for centering */
            text-align: center; /* Center the text inside the nav */
            margin-bottom: 20px; /* Space between nav and container */
        }
        nav ul {
            list-style-type: none;
            padding: 0;
            display: flex;
            justify-content: center;
        }
        nav ul li {
            margin-right: 20px;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
            padding: 10px;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }

        .container {
            max-width: 800px;
            width: 100%;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        /* Post Styling */
        .post {
            border-bottom: 1px solid #ddd;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .post img {
            max-width: 100%;
            border-radius: 5px;
            margin-top: 10px;
        }

        /* Comment Form Styling */
        .comment-form {
            margin-top: 10px;
            display: flex;
            flex-direction: column;
        }
        .comment-form textarea {
            width: 100%;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
            resize: none;
            margin-bottom: 5px;
        }
        .comment-form select,
        .comment-form button {
            padding: 8px;
            font-size: 14px;
            border-radius: 5px;
            border: none;
            margin-bottom: 10px;
            cursor: pointer;
        }
        .comment-form select {
            border: 1px solid #ccc;
        }
        .comment-form button {
            background-color: #4A90E2;
            color: #fff;
        }
        .comment-form button:hover {
            background-color: #357ABD;
        }

        /* Comment Styling */
        .comment {
            padding: 5px 0;
            border-top: 1px solid #ddd;
            margin-top: 10px;
            color: #555;
        }
        .comment strong {
            color: #333;
        }
    </style>
</head>
<body>

    <nav>
        <ul>
            <li><a href="login.php">Login</a></li>
            <li><a href="post.php">Posts</a></li>
            <li><a href="logout.php">Logout</a></li> 
        </ul>
    </nav>

    <div class="container">
        <h1>Sales Blog</h1>

        <!-- Display Posts -->
        <?php
        $stmt = $pdo->query("SELECT * FROM posts ORDER BY created_at DESC");
        while ($post = $stmt->fetch()) {
            echo "<div class='post'>";
            echo "<p>" . htmlspecialchars($post['content']) . "</p>";
            if ($post['image']) {
                echo "<img src='" . htmlspecialchars($post['image']) . "' alt='Image'>";
            }

            // Comment Form
            echo "<form method='POST' action='' class='comment-form'>";
            echo "<input type='hidden' name='post_id' value='" . $post['id'] . "'>";
            echo "<textarea name='comment' placeholder='Write a comment...' required></textarea>";

            // Emoji selection
            echo "<select name='emoji'>";
            echo "<option value=''>Select an emoji</option>";
            echo "<option value='😊'>😊</option>";
            echo "<option value='😂'>😂</option>";
            echo "<option value='❤️'>❤️</option>";
            echo "<option value='😢'>😢</option>";
            echo "<option value='😡'>😡</option>";
            echo "</select>";

            echo "<button type='submit'>Comment</button>";
            echo "</form>";

            // Fetch and display comments for this post
            $commentStmt = $pdo->prepare("SELECT * FROM comments WHERE post_id = ? ORDER BY created_at DESC");
            $commentStmt->execute([$post['id']]);

            while ($comment = $commentStmt->fetch()) {
                echo "<div class='comment'>";
                echo "<p><strong>User " . htmlspecialchars($comment['user_id']) . ":</strong> " . htmlspecialchars($comment['comment']) . "</p>";
                echo "</div>";
            }
            echo "</div>";
        }
        ?>
    </div>
</body>
</html>
