-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2024 at 04:24 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sales_blogs`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `user_id`, `comment`, `created_at`) VALUES
(1, 1, 1, 'what a beatiful place ❤️', '2024-10-30 00:59:53'),
(2, 4, 2, 'how much ❤️', '2024-10-30 01:23:19'),
(3, 3, 2, 'relly ❤️', '2024-10-30 01:23:38'),
(4, 1, 2, 'good view ❤️', '2024-10-30 01:23:53'),
(5, 6, 3, 'wertyu 😢', '2024-10-30 01:56:39'),
(6, 4, 3, 'sdfg 😊', '2024-10-30 01:57:12'),
(7, 6, 4, 'awsedrftghjk 😢', '2024-10-30 01:58:20'),
(8, 7, 5, 'what a beatiful view 😊', '2024-10-30 02:03:41'),
(9, 6, 5, 'gggggg 😡', '2024-10-30 02:03:55');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `content`, `image`, `created_at`) VALUES
(1, 1, 'um not feeling well', 'images/Screenshot 2024-08-19 214142.png', '2024-10-30 00:57:48'),
(2, 1, 'um good', '', '2024-10-30 01:15:48'),
(3, 1, 'um good', '', '2024-10-30 01:16:05'),
(4, 1, 'heyy', 'images/white_t-shirt.jpg', '2024-10-30 01:16:25'),
(5, 3, 'sdfghjk', 'images/Screenshot 2024-10-10 050950.png', '2024-10-30 01:55:37'),
(6, 3, 'rtyuiogf', 'images/dersert.png', '2024-10-30 01:56:13'),
(7, 5, 'hello ', 'images/NIGHT CITY.png', '2024-10-30 02:03:01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'Limpho', '$2y$10$Wi91dsRZ6hM5Ule9oC2xXO2f.nnyD6idE1id9ikSRIlPlY8ckGkW2', '2024-10-30 00:57:03'),
(2, 'Tebelo', '$2y$10$BByDXPUEkWG6ktD4ZKVbreV3KOMZqINAR2fLWqAQ1VnaWFB0VFS9.', '2024-10-30 01:22:34'),
(3, 'Mbhele', '$2y$10$Lf2eqSstTMxcfzs.x5ynyulCO3VW9BKxFGMfpEPkQZv/6mnOjOt4O', '2024-10-30 01:55:03'),
(4, 'Ithabeleng', '$2y$10$4DY6uWVwPsEtq1Og/zxe.eDIs6svsEQgJMFBm2.QX9V1v6mJ1CBYG', '2024-10-30 01:57:43'),
(5, 'tsoeu', '$2y$10$Sa35sHbimgpo4jKrq6Le0e0XnpQBrYrFx90OLtXinOn7aOXEi/XcO', '2024-10-30 02:02:35'),
(6, 'Khotso', '$2y$10$.nD9xWQmGty5zIHfXryVW.kQMK9lDLFqc9/LpFxe0gxNLXwuQfWe6', '2024-10-30 02:45:56'),
(7, 'Tumisang', '$2y$10$H39yBPkZeNVKVnQvT8TVkexVqBkMYnF3YcwIIEAFijB3UntB.JKZm', '2024-10-30 03:17:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
